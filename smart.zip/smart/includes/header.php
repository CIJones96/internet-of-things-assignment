<?php require_once 'php_action/core.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>SOSA Stock Management System</title>
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css"> <!-- Bootstrap -->
   <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css"> <!-- DataTables -->
   <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css"> <!-- JQuery UI -->
   <script src="assests/jquery-ui/jquery-ui.min.js"></script> <!-- /JQuery UI -->
   <script src="assests/bootstrap/js/bootstrap.min.js"></script> <!-- Bootstrap JS -->
   <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css"> <!-- File Input -->
	<script src="assests/jquery/jquery.min.js"></script> <!-- JQuery -->
   <link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css"> <!-- Bootstrap Theme-->
   <link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css"> <!-- Font Awesome -->
   <link rel="stylesheet" href="custom/css/custom.css"> <!-- Custom CSS -->
</head>

<body>
	<nav class="navbar navbar-default navbar-static-top">
	<div class="container">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle Navigation Bar</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
         </button>
      </div> <!-- /navbar-header -->

      <!-- Collect the nav links, forms, and other content for toggling -->
         <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">      
            <ul class="nav navbar-nav navbar-right">        
              	<li id="navHome"><a href="index.php"><i class="glyphicon glyphicon-list-alt"></i>  Home Page</a></li>
               <li id="navCategories"><a href="categories.php"> <i class="glyphicon glyphicon-th-list"></i> Categories</a></li>             
               <li id="navBrand"><a href="brand.php"><i class="glyphicon glyphicon-btc"></i>  Brands</a></li>
               <li id="navProduct"><a href="product.php"> <i class="glyphicon glyphicon-ruble"></i> Products</a></li>           
            </ul> <!-- /ul navbar-right-->
         </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
	</nav> <!-- /navbar-static-top -->

   <div class="container">