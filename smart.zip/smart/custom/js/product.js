var manageProductTable;
$(document).ready(function() {
	$('#navProduct').addClass('active'); 	// Navigation Bar 
	manageProductTable = $('#manageProductTable').DataTable({ // Manage Product Tab
		'ajax': 'php_action/fetchProduct.php'
	});
	
	$("#addProductModalBtn").unbind('click').bind('click', function() { // Add Product Modal Button	
		$(".text-danger").remove(); // Text Error	
		$("#productImage").fileinput({
	      	overwriteInitial: true,
		    maxFileSize: 2500,
		    showClose: false,
		    showCaption: false,
		    browseLabel: '',
		    removeLabel: '',
		    defaultPreviewContent: '<img src="assests/images/photo_default.png" alt="Profile Image" style="width:100%;">',
		    layoutTemplates: {main2: '{preview} {remove} {browse}'},								    
	  		allowedFileExtensions: ["jpg", "png", "gif", "JPG", "PNG", "GIF"]
		    browseIcon: '<i class="glyphicon glyphicon-folder-open"></i>',
		    removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
		    removeTitle: 'Cancel or reset changes',
		    elErrorContainer: '#kv-avatar-errors-1',
		    msgErrorClass: 'alert alert-block alert-danger',
			});   

		
		$("#submitProductForm").unbind('submit').bind('submit', function() { // Submit Product Form
			var productImage = $("#productImage").val(); // Product Image
			var productName = $("#productName").val();	// Product Name
			var brandName = $("#brandName").val();	// Brand Name
			var categoryName = $("#categoryName").val(); // Category Name
			var quantity = $("#quantity").val(); // Quantity 
			var rate = $("#rate").val(); // Rate/Price
			var productStatus = $("#productStatus").val(); // Product Status
	
			if(productImage == "") { // Product Image
				$("#productImage").closest('.center-block').after('<p class="text-danger">Product Image field is required</p>');
				$('#productImage').closest('.form-group').addClass('has-error');
			}	else {
				$("#productImage").find('.text-danger').remove(); // removes error text field
				$("#productImage").closest('.form-group').addClass('has-success');	// success out for form   	
			}	// /else

			if(categoryName == "") { // Category Name
				$("#categoryName").after('<p class="text-danger">Category Name field is required</p>');
				$('#categoryName').closest('.form-group').addClass('has-error');
			}	else {
				$("#categoryName").find('.text-danger').remove();
				$("#categoryName").closest('.form-group').addClass('has-success');	  	
			}	// /else

			if(productName == "") { // Product Name
				$("#productName").after('<p class="text-danger">Product Name field is required</p>');
				$('#productName').closest('.form-group').addClass('has-error');
			}	else {
				$("#productName").find('.text-danger').remove();
				$("#productName").closest('.form-group').addClass('has-success');	  	
			}	// /else

			if(rate == "") { // Rate/Price
				$("#rate").after('<p class="text-danger">Rate field is required</p>');
				$('#rate').closest('.form-group').addClass('has-error');
			}	else {
				
				$("#rate").find('.text-danger').remove();
				$("#rate").closest('.form-group').addClass('has-success');	  	
			}	// /else

			if(brandName == "") { // Brand Name
				$("#brandName").after('<p class="text-danger">Brand Name field is required</p>');
				$('#brandName').closest('.form-group').addClass('has-error');
			}	else {
				$("#brandName").find('.text-danger').remove();
				$("#brandName").closest('.form-group').addClass('has-success');	  	
			}	// /else

			if(quantity == "") { // Quantity
				$("#quantity").after('<p class="text-danger">Quantity field is required</p>');
				$('#quantity').closest('.form-group').addClass('has-error');
			}	else { // remove error text field
				$("#quantity").find('.text-danger').remove(); // success out for form 
				$("#quantity").closest('.form-group').addClass('has-success');	  	
			}	// /else
			
			if(productStatus == "") { // Product Status
				$("#productStatus").after('<p class="text-danger">Product Status field is required</p>');
				$('#productStatus').closest('.form-group').addClass('has-error');
			}	else {
				$("#productStatus").find('.text-danger').remove();
				$("#productStatus").closest('.form-group').addClass('has-success');	  	
			}	// /else

			if(productImage && productName && quantity && rate && brandName && categoryName && productStatus) { // Submit Loading Button
				$("#createProductBtn").button('loading');

				var form = $(this);
				var formData = new FormData(this);

				$.ajax({ // Using Ajax
					url : form.attr('action'),
					type: form.attr('method'),
					data: formData,
					dataType: 'json',
					cache: false,
					contentType: false,
					processData: false,
					success:function(response) {

						if(response.success == true) { // Loading Button
							$("#createProductBtn").button('reset');
							$("#submitProductForm")[0].reset();
							$("html, body, div.modal, div.modal-content, div.modal-body").animate({scrollTop: '0'}, 100);	
							$('#add-product-messages').html('<div class="alert alert-success">'+'<button type="button" class="close" data-dismiss="alert">&times;</button>'+'<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +'</div>');
		          			$(".alert-success").delay(500).show(10, function() {
								$(this).delay(3000).hide(10, function() {
									$(this).remove();
								});
							}); // /.alert-success

							manageProductTable.ajax.reload(null, true); // Manage Product Table Ajax
							$(".text-danger").remove();
							$(".form-group").removeClass('has-error').removeClass('has-success');
						} // /if response.success
					} // /success function
				}); // /ajax function
			}	 // /if validation is ok 					
			return false;
		}); // /submit product form
	}); // /add product modal btn clicked	
}); 
function editProduct(productId = null) {

	if(productId) {
		$("#productId").remove();		
		$(".text-danger").remove();
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$('.div-loading').removeClass('div-hide');
		$('.div-result').addClass('div-hide');

		$.ajax({
			url: 'php_action/fetchSelectedProduct.php',
			type: 'post',
			data: {productId: productId},
			dataType: 'json',
			success:function(response) {		
				$('.div-loading').addClass('div-hide');
				$('.div-result').removeClass('div-hide');				
				$("#getProductImage").attr('src', 'stock/'+response.product_image);
				$("#editProductImage").fileinput({		      
				}); 
				
				$("#editProductName").val(response.product_name);
				$("#editBrandName").val(response.brand_id);
				$("#editCategoryName").val(response.categories_id);
				$(".editProductFooter").append('<input type="hidden" name="productId" id="productId" value="'+response.product_id+'" />');				
				$(".editProductPhotoFooter").append('<input type="hidden" name="productId" id="productId" value="'+response.product_id+'" />');				
				$("#editProductStatus").val(response.active);
				$("#editQuantity").val(response.quantity);
				$("#editRate").val(response.rate);
				$("#editProductForm").unbind('submit').bind('submit', function() {

					var productImage = $("#editProductImage").val();
					var productName = $("#editProductName").val();
					var quantity = $("#editQuantity").val();
					var rate = $("#editRate").val();
					var brandName = $("#editBrandName").val();
					var categoryName = $("#editCategoryName").val();
					var productStatus = $("#editProductStatus").val();		

					if(productName == "") {
						$('#editProductName').closest('.form-group').addClass('has-error');
						$("#editProductName").after('<p class="text-danger">Product Name field is required</p>');
					}	else {
						$("#editProductName").closest('.form-group').addClass('has-success');
						$("#editProductName").find('.text-danger').remove();	  	
					}
					if(quantity == "") {
						$("#editQuantity").after('<p class="text-danger">Quantity field is required</p>');
						$('#editQuantity').closest('.form-group').addClass('has-error');
					}	else {
						$("#editQuantity").find('.text-danger').remove();
						$("#editQuantity").closest('.form-group').addClass('has-success');	  	
					}
					if(rate == "") {
						$("#editRate").after('<p class="text-danger">Rate field is required</p>');
						$('#editRate').closest('.form-group').addClass('has-error');
					}	else {
						$("#editRate").find('.text-danger').remove();
						$("#editRate").closest('.form-group').addClass('has-success');	  	
					}

					if(brandName == "") {
						$("#editBrandName").after('<p class="text-danger">Brand Name field is required</p>');
						$('#editBrandName').closest('.form-group').addClass('has-error');
					}	else {
						$("#editBrandName").find('.text-danger').remove();
						$("#editBrandName").closest('.form-group').addClass('has-success');	  	
					}

					if(categoryName == "") {
						$("#editCategoryName").after('<p class="text-danger">Category Name field is required</p>');
						$('#editCategoryName').closest('.form-group').addClass('has-error');
					}	else {
						$("#editCategoryName").find('.text-danger').remove();
						$("#editCategoryName").closest('.form-group').addClass('has-success');	  	
					}

					if(productStatus == "") {
						$("#editProductStatus").after('<p class="text-danger">Product Status field is required</p>');
						$('#editProductStatus').closest('.form-group').addClass('has-error');
					}	else {
						$("#editProductStatus").find('.text-danger').remove();
						$("#editProductStatus").closest('.form-group').addClass('has-success');	  	
					}					

					if(productName && quantity && rate && brandName && categoryName && productStatus) {
						$("#editProductBtn").button('loading');
						var form = $(this);
						var formData = new FormData(this);
						$.ajax({
							url : form.attr('action'),
							type: form.attr('method'),
							data: formData,
							dataType: 'json',
							cache: false,
							contentType: false,
							processData: false,
							success:function(response) {
								console.log(response);
								if(response.success == true) {
									$("#editProductBtn").button('reset');																		
									$("html, body, div.modal, div.modal-content, div.modal-body").animate({scrollTop: '0'}, 100);
									$('#edit-product-messages').html('<div class="alert alert-success">'+'<button type="button" class="close" data-dismiss="alert">&times;</button>'+'<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +'</div>');
				          $(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									});
									manageProductTable.ajax.reload(null, true);
									$(".text-danger").remove();
									$(".form-group").removeClass('has-error').removeClass('has-success');
								}	
							} 
						}); 
					}					
					return false;
				});
		
				$("#updateProductImageForm").unbind('submit').bind('submit', function() {					
					var productImage = $("#editProductImage").val();					
					
					if(productImage == "") {
						$("#editProductImage").closest('.center-block').after('<p class="text-danger">Product Image field is required</p>');
						$('#editProductImage').closest('.form-group').addClass('has-error');
					}	else {
						$("#editProductImage").find('.text-danger').remove();
						$("#editProductImage").closest('.form-group').addClass('has-success');	  	
					}	

					if(productImage) {
						$("#editProductImageBtn").button('loading');
						var form = $(this);
						var formData = new FormData(this);

						$.ajax({
							url : form.attr('action'),
							type: form.attr('method'),
							data: formData,
							dataType: 'json',
							cache: false,
							contentType: false,
							processData: false,
							success:function(response) {
								
								if(response.success == true) {
									$("#editProductImageBtn").button('reset');																		
									$("html, body, div.modal, div.modal-content, div.modal-body").animate({scrollTop: '0'}, 100);
									$('#edit-productPhoto-messages').html('<div class="alert alert-success">'+'<button type="button" class="close" data-dismiss="alert">&times;</button>'+'<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +'</div>');
				          $(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									});
									manageProductTable.ajax.reload(null, true);
									$(".fileinput-remove-button").click();
									$.ajax({
										url: 'php_action/fetchProductImageUrl.php?i='+productId,
										type: 'post',
										success:function(response) {
										$("#getProductImage").attr('src', response);		
										}
									});																		
									$(".text-danger").remove();
									$(".form-group").removeClass('has-error').removeClass('has-success');
								}	
							} 
						});
					}				
					return false;
				});
			}
		}); 
				
	} else {
		alert('error please refresh the page');
	}
} 
function removeProduct(productId = null) {
	if(productId) {
		$("#removeProductBtn").unbind('click').bind('click', function() {
			$("#removeProductBtn").button('loading');
			$.ajax({
				url: 'php_action/removeProduct.php',
				type: 'post',
				data: {productId: productId},
				dataType: 'json',
				success:function(response) {
					$("#removeProductBtn").button('reset');
					if(response.success == true) {

						$(".alert-success").delay(500).show(10, function() {
							$(this).delay(3000).hide(10, function() {
								$(this).remove();
							});
						});

						$("#removeProductModal").modal('hide');
						manageProductTable.ajax.reload(null, false);
						$(".remove-messages").html('<div class="alert alert-success">'+'<button type="button" class="close" data-dismiss="alert">&times;</button>'+'<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +'</div>');
	          
					} else {
						$(".removeProductMessages").html('<div class="alert alert-success">'+'<button type="button" class="close" data-dismiss="alert">&times;</button>'+'<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +'</div>');
	          $(".alert-success").delay(500).show(10, function() {
							$(this).delay(3000).hide(10, function() {
								$(this).remove();
							});
						});
					}
				}
			});
			return false;
		});
	}
}