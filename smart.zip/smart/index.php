  <?php require_once 'header.php'; ?> <!-- Checks if the file has already been included -->
  <?php require_once 'php_action/db_connect.php' ?>  <!-- Checks if the database has been connected -->

  <?php 
  	//Counting total smart products in database
  	$sql = "SELECT * FROM smart WHERE status = 1";
  	$query = $connect->query($sql);
  	$countProduct = $query->num_rows;

  	//Counting number of products that have a quantity of 10 or less.
  	//Gets displayed as 'low stock'
  	$lowStockSql = "SELECT * FROM smart WHERE quantity <= 10 AND status = 1";
  	$lowStockQuery = $connect->query($lowStockSql);
  	$countLowStock = $lowStockQuery->num_rows;
  ?>

  <div class="container"> <!-- container -->

    <!-- Low Stock Panel -->
    <div class="col-md-6">
      <div class="panel panel-danger">
        <div class="panel-heading">
          <a href="smart.php" style="text-decoration:none;color:black;">
            Low Stock
            <span class="badge pull pull-right"><?php echo $countLowStock; ?></span>  
          </a>
        </div> <!--/panel-hdeaing-->
      </div> <!--/panel-->
    </div> <!--/col-md-6-->

  	<!-- Counting Total Products Panel -->
  	<div class="col-md-6">
  		<div class="panel panel-success">
  			<div class="panel-heading">
  				
  				<a href="smart.php" style="text-decoration:none;color:black;">
  					Total Smart Products
  					<span class="badge pull pull-right"><?php echo $countProduct; ?></span>	
  				</a>
  				
  			</div> <!--/panel-hdeaing-->
  		</div> <!--/panel-->
  	</div> <!--/col-md-4-->

     <!-- Heading Row -->
     <div class="row">
        <div class="col-md-8">
           <img class="img-responsive img-rounded" src="photo.jpg" alt="">
        </div> <!-- /.col-md-8 -->
          
        <div class="col-md-4">
           <h1>SOSA Product Management System</h1>
          		<p>Product Management Console created for the e-commerce website of SOSA. Builing
                 to replace the existing stock management system that was using Microsoft Access. 
                 <br><br>
                 Using PHP and SQL to develop the system, it is able to add, edit and delete products with
                 ease. It can also search for individual products very efficiently.
                 <br><br>
                 I have also created a technical that contains the ERD and description of the php files that I have created for this project.
                 <br>
                 It also had a self-assessment check list which has been implemented.
              </p>
          	</div> <!-- /.col-md-4 -->
      	</div> <!-- /.row -->
      	
      	<hr>
        <!-- Call to Action Well --> 
      	<div class="row">
          	<div class="col-lg-12">
              <div class="well text-center">
                 &copy; Christopher Jones - i7467340
              </div>
          	</div> <!-- /.col-lg-12 -->
      	</div> <!-- /.row -->

      <!-- Content Row -->
      <div class="row">
      	<div class="col-md-4">
           <h2>Brands</h2>
           <p>
              In this section, the user is able to create, edit and delete brands of clothing and accessories that will be sold on the e-commerce website.
              The users are also able to search for brands very quick and easy.
           </p>
        </div> <!-- /.col-md-4 -->
          
        <div class="col-md-4">
           <h2>Categories</h2>
          		<p>Users have the ability to create, edit and delete categories that group specific clothing/accessories together.
          	     Also able to search for an individual category very easily.
          	 	</p>
        </div> <!-- /.col-md-4 -->
          
        <div class="col-md-4">
              <h2>Products</h2>
          	    <p>
          	    	Using the brands and the categories that the users have added to the database, products can be added, editted and deleted.
          	    </p>
        </div> <!-- /.col-md-4 -->
     </div> <!-- /.row --> 
  </div>
  <!-- /container -->  
  <!-- Checks if the file has already been included -->
  <?php require_once 'footer.php'; ?> <!-- Checks if the file has already been included -->