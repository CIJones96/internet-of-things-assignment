<?php 
	session_start(); // Start new or resume existing session
	require_once 'db_connect.php'; // Making sure database has successfully connected to the site
?>